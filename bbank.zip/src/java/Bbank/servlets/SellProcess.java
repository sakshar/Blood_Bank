/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bbank.servlets;

import Bbank.db.DataAccess;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Dell
 */
@WebServlet(name = "SellProcess", urlPatterns = {"/SellProcess.bb"})
public class SellProcess extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String rid = request.getParameter("RID");
        String bb_id = request.getParameter("BID");
        String priceRaw = request.getParameter("price");
        double price = Double.parseDouble(priceRaw);
        String sellresult;
        DataAccess db = new DataAccess();
        boolean rem = db.isSoldorExpired(bb_id);
        if(!rem)
        {
            int count = db.existRecipient(rid);
            if(count==1)
            {
                count = db.existBloodBag(bb_id);
                if(count==1)
                {
                    count = db.sellBlood(rid,bb_id,price);
                    if(count == 1)
                    {
                        sellresult = "Blood Bag Sold Successfully!!";
                    }
                    else
                    {
                        sellresult = "Blood Bag Sale Failed. Suggested to Check Blood Type Mismatch!!";
                    }
                    //RequestDispatcher rd = request.getRequestDispatcher("index.html");
                    //rd.forward(request, response);
                }
                else
                {
                    sellresult = "Blood_Bag_ID does not exist!!";
                    //RequestDispatcher rd = request.getRequestDispatcher("index.html");
                    //rd.forward(request, response);
                }
            }
            else
            {
                sellresult = "Recipient_ID does not exist";
                //RequestDispatcher rd = request.getRequestDispatcher("AddBloodBag.jsp");
                //rd.forward(request, response);
            }
        }
        else
        {
            sellresult = "Blood_Bag Already Sold or Expired";
        }
        HttpSession session = request.getSession();
        session.setAttribute("sellresult", sellresult);
        RequestDispatcher rd = request.getRequestDispatcher("Sales.jsp");
        rd.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bbank.models;

/**
 *
 * @author Dell
 */
public class Inventory {
    String Blood_type;
    double unit;

    public Inventory(String Blood_type, double unit) {
        this.Blood_type = Blood_type;
        this.unit = unit;
    }

    public String getBlood_type() {
        return Blood_type;
    }

    public void setBlood_type(String Blood_type) {
        this.Blood_type = Blood_type;
    }

    public double getUnit() {
        return unit;
    }

    public void setUnit(double unit) {
        this.unit = unit;
    }
    
    
}

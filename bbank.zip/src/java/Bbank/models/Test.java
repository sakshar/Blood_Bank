/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bbank.models;

/**
 *
 * @author Dell
 */
public class Test {
    String tid;
    String eid;
    String bb_id;
    String hiv;
    String hb;
    String hcv;
    String syp;
    double rbc;

    public Test(String tid, String eid, String bb_id, String hiv, String hb, String hcv, String syp, double rbc) {
        this.tid = tid;
        this.eid = eid;
        this.bb_id = bb_id;
        this.hiv = hiv;
        this.hb = hb;
        this.hcv = hcv;
        this.syp = syp;
        this.rbc = rbc;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getEid() {
        return eid;
    }

    public void setEid(String eid) {
        this.eid = eid;
    }

    public String getBb_id() {
        return bb_id;
    }

    public void setBb_id(String bb_id) {
        this.bb_id = bb_id;
    }

    public String getHiv() {
        return hiv;
    }

    public void setHiv(String hiv) {
        this.hiv = hiv;
    }

    public String getHb() {
        return hb;
    }

    public void setHb(String hb) {
        this.hb = hb;
    }

    public String getHcv() {
        return hcv;
    }

    public void setHcv(String hcv) {
        this.hcv = hcv;
    }

    public String getSyp() {
        return syp;
    }

    public void setSyp(String syp) {
        this.syp = syp;
    }

    public double getRbc() {
        return rbc;
    }

    public void setRbc(double rbc) {
        this.rbc = rbc;
    }
    
}

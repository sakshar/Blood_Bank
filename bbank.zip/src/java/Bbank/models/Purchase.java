/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bbank.models;

/**
 *
 * @author Dell
 */
public class Purchase {
    String rc_id;
    String rp_id;
    String name;
    String bb_id;
    String b_type;
    String date;
    double price;

    public Purchase(String rc_id, String rp_id, String name, String bb_id, String b_type, String date, double price) {
        this.rc_id = rc_id;
        this.rp_id = rp_id;
        this.name = name;
        this.bb_id = bb_id;
        this.b_type = b_type;
        this.date = date;
        this.price = price;
    }

    public String getRc_id() {
        return rc_id;
    }

    public void setRc_id(String rc_id) {
        this.rc_id = rc_id;
    }

    public String getRp_id() {
        return rp_id;
    }

    public void setRp_id(String rp_id) {
        this.rp_id = rp_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBb_id() {
        return bb_id;
    }

    public void setBb_id(String bb_id) {
        this.bb_id = bb_id;
    }

    public String getB_type() {
        return b_type;
    }

    public void setB_type(String b_type) {
        this.b_type = b_type;
    }
    
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    
    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    
}

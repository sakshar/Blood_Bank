/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bbank.models;

/**
 *
 * @author Dell
 */
public class AvailableDonors {
    String bloodType;
    String name;
    String did;
    String mob;
    String mail;
    String lastDonated;
    double donationCount;

    public AvailableDonors(String bloodType, String name, String did, String mob, String mail, String lastDonated, double donationCount) {
        this.bloodType = bloodType;
        this.name = name;
        this.did = did;
        this.mob = mob;
        this.mail = mail;
        this.lastDonated = lastDonated;
        this.donationCount = donationCount;
    }

    public String getBloodType() {
        return bloodType;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public String getDid() {
        return did;
    }

    public void setDid(String did) {
        this.did = did;
    }
    public String getMob() {
        return mob;
    }

    public void setMob(String mob) {
        this.mob = mob;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getLastDonated() {
        return lastDonated;
    }

    public void setLastDonated(String lastDonated) {
        this.lastDonated = lastDonated;
    }

    public double getDonationCount() {
        return donationCount;
    }

    public void setDonationCount(double donationCount) {
        this.donationCount = donationCount;
    }

    
    
}

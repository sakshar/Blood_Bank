/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bbank.db;

import Bbank.models.AvailableDonors;
import Bbank.models.Inventory;
import Bbank.models.Purchase;
import Bbank.models.Test;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class DataAccess {
    String dbURL = "jdbc:oracle:thin:@localhost:1521:ORCL";
    String username = "bbank";
    String password = "123";

    Connection conn = null;
    public DataAccess()
    {
        try
        {
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection(dbURL, username, password);
            if(conn!=null) System.out.println("Connection successfully established.");
            else System.out.println("Could not establish connection");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public int createBothAccount(String firstname, String lastname,String username,
            String password,String address,String dob,String mob,String mail,String blood,
            String gender,String designation)
    {
        try
        {
            String insertCommand = "insert into accounts values(?,?,?)";
            PreparedStatement stmt = conn.prepareStatement(insertCommand);
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, "Both");
            int count = stmt.executeUpdate();
            if(count==1)
            {
                String sql = "{ ? = call CREATE_BOTH_ACCOUNT(?,?,?,?,?,?,?,?,?,?) }";
                CallableStatement statement = conn.prepareCall(sql);
                statement.setString(2,username);
                statement.setString(3,firstname);
                statement.setString(4,lastname);
                statement.setString(5,address);
                statement.setString(6,dob);
                statement.setString(7,blood);
                statement.setString(8,gender);
                statement.setString(9,mob);
                statement.setString(10,mail);
                statement.setString(11,designation);
                statement.registerOutParameter(1, java.sql.Types.INTEGER);  

                statement.execute();   
                //this is the main line
                long id = statement.getLong(1);
                if (id > 0) {
                    count = 1;
                } else {
                    count = 0;
                }
            }
            return count;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return 0;
        }       
    }
    
    public int createDonorAccount(String firstname, String lastname,String username,
            String password,String address,String dob,String mob,String mail,String blood,
            String gender)
    {
        try
        {
            String insertCommand = "insert into accounts values(?,?,?)";
            PreparedStatement stmt = conn.prepareStatement(insertCommand);
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, "Donor");
            int count = stmt.executeUpdate();
            if(count==1)
            {
                String sql = "{ ? = call CREATE_DONOR_ACCOUNT(?,?,?,?,?,?,?,?,?) }";
                CallableStatement statement = conn.prepareCall(sql);
                statement.setString(2,username);
                statement.setString(3,firstname);
                statement.setString(4,lastname);
                statement.setString(5,address);
                statement.setString(6,dob);
                statement.setString(7,blood);
                statement.setString(8,gender);
                statement.setString(9,mob);
                statement.setString(10,mail);
                statement.registerOutParameter(1, java.sql.Types.INTEGER);  

                statement.execute();   
                //this is the main line
                long id = statement.getLong(1);
                if (id > 0) {
                    count = 1;
                } else {
                    count = 0;
                }
            }
            return count;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return 0;
        }       
    }
    
    public int createEmployeeAccount(String firstname, String lastname,String username,
            String password,String address,String dob,String mob,String mail,String blood,
            String gender,String designation)
    {
        try
        {
            String insertCommand = "insert into accounts values(?,?,?)";
            PreparedStatement stmt = conn.prepareStatement(insertCommand);
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, "Employee");
            int count = stmt.executeUpdate();
            if(count==1)
            {
                String sql = "{ ? = call CREATE_EMPLOYEE_ACCOUNT(?,?,?,?,?,?,?,?,?,?) }";
                CallableStatement statement = conn.prepareCall(sql);
                statement.setString(2,username);
                statement.setString(3,firstname);
                statement.setString(4,lastname);
                statement.setString(5,address);
                statement.setString(6,dob);
                statement.setString(7,blood);
                statement.setString(8,gender);
                statement.setString(9,mob);
                statement.setString(10,mail);
                statement.setString(11,designation);
                statement.registerOutParameter(1, java.sql.Types.INTEGER);  

                statement.execute();   
                //this is the main line
                long id = statement.getLong(1);
                if (id > 0) {
                    count = 1;
                } else {
                    count = 0;
                }
            }
            return count;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return 0;
        }       
    }
    
    public int placeDemand(String firstname, String lastname,String ref,
            String disease,String address,String dob,String mob,String mail,String blood,
            String gender,double d_date, String hospital, double unit)
    {
        try
        {
            String insertCommand = "insert into recipients values(Recipient_ID_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,?,"
                    + "SYSDATE+?, TO_DATE(?,'DD-MON-YYYY'),?,?)";
            PreparedStatement stmt = conn.prepareStatement(insertCommand);
            stmt.setString(1, firstname);
            stmt.setString(2, lastname);
            stmt.setString(3, address);
            stmt.setString(4, mob);
            stmt.setString(5, mail);
            stmt.setString(6, blood);
            stmt.setString(7, disease);
            stmt.setString(8, hospital);
            stmt.setDouble(9, unit);
            stmt.setDouble(10, d_date);
            stmt.setString(11, dob);
            stmt.setString(12, gender);
            stmt.setString(13, ref);
            int count = stmt.executeUpdate();
            return count;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return 0;
        }       
    }
    
    public int addBloodBag(String donor_id, String expire)
    {
        try
        {
            String insertCommand = "insert into blood_bags values(BB_ID_SEQ.NEXTVAL,?,SYSDATE,ADD_MONTHS(SYSDATE,?),?)";
            PreparedStatement stmt = conn.prepareStatement(insertCommand);
            stmt.setString(1, donor_id);
            stmt.setString(2, expire);
            stmt.setString(3, "Untested");
            int count = stmt.executeUpdate();
            return count;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return 0;
        }       
    }
    
    public int addTestReport(String eid, String bb_id, double rbc, String hiv,
            String hcv, String hb, String syp)
    {
        try
        {
            String insertCommand = "insert into tests values(TEST_ID_SEQ.NEXTVAL,?,?,?,?,?,?,?)";
            PreparedStatement stmt = conn.prepareStatement(insertCommand);
            stmt.setString(1, eid);
            stmt.setString(2, bb_id);
            stmt.setString(3, hiv);
            stmt.setString(4, hb);
            stmt.setString(5, hcv);
            stmt.setString(6, syp);
            stmt.setDouble(7, rbc);
            int count = stmt.executeUpdate();
            return count;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return 0;
        }       
    }
    
    public int sellBlood(String rid, String bb_id, double price)
    {
        try
        {
            String sql = "{ ? = call SELL_BLOOD(?,?,?) }";
            CallableStatement statement = conn.prepareCall(sql);
            statement.setString(2,rid);
            statement.setString(3,bb_id);
            statement.setDouble(4,price);
            statement.registerOutParameter(1, java.sql.Types.INTEGER);  

            statement.execute();   
                //this is the main line
            long id = statement.getLong(1);
            int count=0;
            if (id > 0) {
                count = 1;
            }
            return count;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return 0;
        }       
    }
    
    public int existUser(String username,String password)
    {
        try
        {
            String query = "select * from accounts where username = ? and password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            if(rs.next())
            {
                if(rs.getString("Account_Type").equals("Donor")) return 1;
                else if(rs.getString("Account_Type").equals("Employee")) return 2;
                else return 3;
            }
            return 0;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return 0;
        }
        
    }
        public int existDonor(String donor_id)
        {
            try
            {
                String query = "select * from donors where Donor_ID = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1,donor_id);
                ResultSet rs = stmt.executeQuery();
                if(rs.next())
                {
                    return 1;
                }
                return 0;
            }
            catch(Exception e)
            {
                e.printStackTrace();
                return 0;
            }

        }
        public String canDonate(String donor_id)
        {
            try
            {
                String sql = "{ ? = call CAN_DONATE(?) }";
                CallableStatement statement = conn.prepareCall(sql);
                statement.setString(2,donor_id);
                statement.registerOutParameter(1, java.sql.Types.VARCHAR);  

                statement.execute();   
                //this is the main line
                String msg = statement.getString(1);
                return msg;
            }
            catch(Exception e)
            {
                e.printStackTrace();
                return null;
            }

        }
    public int existEmployee(String eid)
    {
            try
            {
                String query = "select * from employees where Employee_ID = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1,eid);
                ResultSet rs = stmt.executeQuery();
                if(rs.next())
                {
                    return 1;
                }
                return 0;
            }
            catch(Exception e)
            {
                e.printStackTrace();
                return 0;
            }

    }
    
    public int existRecipient(String rid)
    {
            try
            {
                String query = "select * from recipients where Recipient_ID = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1,rid);
                ResultSet rs = stmt.executeQuery();
                if(rs.next())
                {
                    return 1;
                }
                return 0;
            }
            catch(Exception e)
            {
                e.printStackTrace();
                return 0;
            }

    }
    
    public int existBloodBag(String bb_id)
    {
            try
            {
                String query = "select * from blood_bags where Blood_Bag_ID = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1,bb_id);
                ResultSet rs = stmt.executeQuery();
                if(rs.next())
                {
                    return 1;
                }
                return 0;
            }
            catch(Exception e)
            {
                e.printStackTrace();
                return 0;
            }

    }
    
    public Test getTestReport(String tid)
    {
            try
            {
                /*String query = "select TEST_ID, EMPLOYEE_ID, BLOOD_BAG_ID,"
                        + "HIV, HBSAG, HCV, SYPHILIS, RBC  from tests where TEST_ID = ?";*/
                String query = "select * from tests  where TEST_ID = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1,tid);
                ResultSet rs = stmt.executeQuery();
                if(rs.next())
                {
                    String Tid = rs.getString("TEST_ID");
                    String eid = rs.getString("EMPLOYEE_ID");
                    String bb_id = rs.getString("BLOOD_BAG_ID");
                    String hiv = rs.getString("HIV");
                    String hb = rs.getString("HBSAG");
                    String hcv = rs.getString("HCV");
                    String syp = rs.getString("SYPHILIS");
                    double rbc = rs.getDouble("RBC");
                    Test test = new Test(Tid,eid,bb_id,hiv,hb,hcv,syp,rbc);
                    return test;
                }
                return new Test("","","","","","","",0);
            }
            catch(Exception e)
            {
                e.printStackTrace();
                return null;
            }

    }
    
    public ArrayList<Purchase> searchPurchases(String type, String key)
    {
        ArrayList<Purchase> purchases = new ArrayList<Purchase>();
            try
            {
                String query = "SELECT Receipt_ID, Recipient_ID, (First_Name || ' ' || Last_Name) Name,\n" +
                                "Blood_Bag_ID, Blood_Type, TO_CHAR(Purchase_Date,'DD-MON-YYYY') P_Date, Price\n" +
                                "FROM PURCHASES NATURAL JOIN RECIPIENTS\n"+
                                "WHERE "+type+" = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                if(type.equals("price"))
                {
                    double pr = Double.parseDouble(key);
                    stmt.setDouble(1,pr);
                }
                else
                {
                    stmt.setString(1,key);
                }
                ResultSet rs = stmt.executeQuery();
                while(rs.next())
                {
                    String rc_id = rs.getString("RECEIPT_ID");
                    String rp_id = rs.getString("RECIPIENT_ID");
                    String bb_id = rs.getString("BLOOD_BAG_ID");
                    String name = rs.getString("NAME");
                    String b_type = rs.getString("BLOOD_TYPE");
                    String date = rs.getString("P_DATE");
                    double price = rs.getDouble("PRICE");
                    Purchase purchase = new Purchase(rc_id,rp_id,name,bb_id,b_type,date,price);
                    purchases.add(purchase);
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        return purchases;
    }
    
    public boolean isSoldorExpired(String bb_id)
    {
            try
            {
                String query = "select remarks from blood_bags where Blood_Bag_ID = ?";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1,bb_id);
                ResultSet rs = stmt.executeQuery();
                if(rs.next())
                {
                    String remarks = rs.getString("remarks");
                    if(remarks.equals("Sold")||remarks.equals("Expired"))
                    {
                        return true;
                    }
                }
                return false;
            }
            catch(Exception e)
            {
                e.printStackTrace();
                return false;
            }

    }
    
    public ArrayList<AvailableDonors> getAvailableDonors(String blood)
    {
        ArrayList<AvailableDonors> availDonors = new ArrayList<AvailableDonors>();
        System.out.println("outside " + blood);
        String selectStatement;
        int i=0;
        if(blood.equals("All"))
        {
            i = 1;
            selectStatement = "SELECT P.Blood_Type, (P.FIRST_NAME || ' ' || P.LAST_NAME) NAME, D.DONOR_ID, C.MOBILE_NO,\n" +
                                "E.EMAIL, D.LAST_DONATED, D.DONATION_COUNT\n" +
                                "FROM PERSONS P JOIN DONORS D\n" +
                                "ON (P.Person_ID = D.Person_ID) JOIN CONTACTS C\n" +
                                "ON (P.Person_ID = C.Person_ID) JOIN EMAILS E\n" +
                                "ON (P.Person_ID = E.Person_ID)\n" +
                                "WHERE (SYSDATE - D.LAST_DONATED)/30 >= 4 OR D.Donation_Count = 0\n" +
                                "ORDER BY P.Blood_Type ASC, (SYSDATE - D.LAST_DONATED) DESC";
        }
        else
        {
            System.out.println("inside selectstatement " + blood);
            selectStatement = "SELECT P.Blood_Type, (P.FIRST_NAME || ' ' || P.LAST_NAME) NAME, D.DONOR_ID, C.MOBILE_NO,\n" +
                                "E.EMAIL, D.LAST_DONATED, D.DONATION_COUNT\n" +
                                "FROM PERSONS P JOIN DONORS D\n" +
                                "ON (P.Person_ID = D.Person_ID) JOIN CONTACTS C\n" +
                                "ON (P.Person_ID = C.Person_ID) JOIN EMAILS E\n" +
                                "ON (P.Person_ID = E.Person_ID)\n" +
                                "WHERE P.Blood_Type = ? AND ((SYSDATE - D.LAST_DONATED)/30 >= 4 OR D.Donation_Count = 0)\n" +
                                "ORDER BY (SYSDATE - D.LAST_DONATED) DESC";
        }
        try
        {    
            PreparedStatement stmt = conn.prepareStatement(selectStatement);
            if(i==0){
                //System.out.println("inside if " + blood);
                stmt.setString(1, blood);
                //System.out.println("inside if After " + blood);
            }
            ResultSet rs = stmt.executeQuery();
            while(rs.next())
            {   
                String blood_type = rs.getString("Blood_Type");
                
                System.out.println("inside "+blood_type);
                
                String name = rs.getString("NAME");
                String did = rs.getString("DONOR_ID");
                String mob = rs.getString("MOBILE_NO");
                String mail = rs.getString("EMAIL");
                String date = rs.getString("LAST_DONATED");
                double count = rs.getDouble("DONATION_COUNT");
                AvailableDonors donors = new AvailableDonors(blood_type, name, did, mob,mail,date,count);
                availDonors.add(donors);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        return availDonors;

    }
    
    public ArrayList<Inventory> checkInventory(String blood)
    {
        ArrayList<Inventory> inventory = new ArrayList<Inventory>();
        System.out.println("outside " + blood);
        String selectStatement;
        int j=0;
        if(blood.equals("All"))
        {
            j = 1;
            selectStatement = "Select Blood_Type, COUNT(*) Unit\n" +
                                "From Blood_Inventory NATURAL JOIN BLOOD_BAGS\n" +
                                "NATURAL JOIN DONORS NATURAL JOIN PERSONS\n" +
                                "GROUP BY Blood_Type\n" +
                                "ORDER BY Blood_Type ASC";
        }
        else
        {
            System.out.println("inside selectstatement " + blood);
            selectStatement = "Select Blood_Type, COUNT(*) Unit\n" +
                                "From Blood_Inventory NATURAL JOIN BLOOD_BAGS\n" +
                                "NATURAL JOIN DONORS NATURAL JOIN PERSONS\n" +
                                "WHERE Blood_Type = ?\n" +
                                "GROUP BY Blood_Type\n" +
                                "ORDER BY Blood_Type ASC";
        }
        try
        {    
            PreparedStatement stmt = conn.prepareStatement(selectStatement);
            if(j==0){
                System.out.println("inside if " + blood + " " +j);
                stmt.setString(1, blood);
                System.out.println("inside if After " + blood + " " +j);
            }
            ResultSet rs = stmt.executeQuery();
            while(rs.next())
            {   
                String blood_type = rs.getString("Blood_Type");
                
                System.out.println("inside "+blood_type);
                
                double unit = rs.getDouble("Unit");
                Inventory invent = new Inventory(blood_type,unit);
                inventory.add(invent);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        return inventory;

    }
    
    public boolean expirationCheck()
    {
        try
        {
            String sql = "{ ? = call EXPIRATION_CHECK }";
            CallableStatement statement = conn.prepareCall(sql); 

            statement.execute();
            /*String sql = "exec Expiration_check";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.executeQuery();*/
            //long id = statement.getLong(1);
            return true;
            /*if (id > 0) {
                return true;
            } else {
                return false;
            }*/
                    
        }
        
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
            
    }
    
    /*public boolean userTypeDonor(String username){
        try{
            String query = "select * from donors where person_id = (select person_id from persons where username = ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if(rs.next())
            {
                return true;
            }
            return false;
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
    public boolean userTypeEmployee(String username){
        try{
            String query = "select * from employees where person_id = (select person_id from persons where username = ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if(rs.next())
            {
                return true;
            }
            return false;
        }
        catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }*/
}
